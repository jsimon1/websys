Jeremy Simon - Lab 8

Part 1 - I created the tables using the phpmyadmin interface, so the SQL commands to make them are not included in the commands file.

Part 2 - Inserted everything manually, wasn't sure if there was an easier way? Otherwise, all the parts were pretty straight forward except for part 8, where I wasn't quite sure how to reference across tables using the foreign key.

Exported my table structure/content in a nice-looking doc, and then a .txt file as requested.

All commands I typed into the SQL command line are in commands.txt