<?php
$config = array(
   'DB_HOST'     => 'localhost',
   'DB_USERNAME' => 'root',
   'DB_PASSWORD' => 'test_pass',
);