Jeremy Simon - Lab 9
Lab was pretty straightforward using the PDO examples from class. The only thing that gave me trouble was the final part on querying the count of students that had average grades within a given range. While I'm sure there are queries that could do this all at once, I couldn't quite figure that out so I did a simple query on grades and grouped by the rin, sorting out which grade falls into which distribution after in the PHP.

config.php holds the database information.
data.txt holds the exported phpMyAdmin.

The reason why this is a few hours late is because I was feeling sick earlier and couldn't work on it earlier to finish it up.